﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Project_App
{
    /// <summary>
    /// Логика взаимодействия для AltProductPage.xaml
    /// </summary>

    public partial class AltProductPage : Page
    {

        public AltProductPage()
        {
            InitializeComponent();
            var allManufacturers = SaparovEntities.GetContext().Manufacturer.ToList();
            allManufacturers.Insert(0, new Manufacturer
            {
                Name = "Все производители"
            });
            ComboType.ItemsSource = allManufacturers;
            ComboType.SelectedIndex = 0;
            UpdateProduct();

            var currentProduct = SaparovEntities.GetContext().Product.ToList();
            LViewProduct.ItemsSource = currentProduct;

        }
        private void UpdateProduct()
       {
            var currentProduct = SaparovEntities.GetContext().Product.ToList();

           // if (ComboType.SelectedIndex > 0)
                //currentProduct = currentProduct.Where.Manufacturers.Contains(ComboType.SelectedItem as Manufacturer);

            if (CheckActive.IsChecked.Value)
                currentProduct = currentProduct.Where(p => p.IsActive).ToList();

            currentProduct = currentProduct.Where(p => p.Title.ToLower().Contains(TBoxSearch.Text.ToLower())).ToList();
            LViewProduct.ItemsSource = currentProduct;

        }

        private void TBoxSearch_TextChanged(object sender, TextChangedEventArgs e)
        {
            UpdateProduct();


        }

        private void ComboType_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            
           
        }

        private void CheckActive_Checked(object sender, RoutedEventArgs e)
        {
            UpdateProduct();
        }

    }
}