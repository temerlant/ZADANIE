﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Project_App
{
    /// <summary>
    /// Логика взаимодействия для AddEditPage.xaml
    /// </summary>
    public partial class AddEditPage : Page
    {
        private Product _currentProduct = new Product();
        public AddEditPage(Product selectedProduct)

        {
            InitializeComponent();
            ComboManufacturer.ItemsSource = SaparovEntities2.GetContext().Manufacturers.ToList();
            if (selectedProduct != null)
                _currentProduct = selectedProduct;

            DataContext = _currentProduct;

                       
            
        }

        private void BtnSave_Click(object sender, RoutedEventArgs e)
        {
            StringBuilder errors = new StringBuilder();

            if (string.IsNullOrWhiteSpace(_currentProduct.Title))
                errors.AppendLine("Укажите название продукта");
            if (_currentProduct.Cost < 1 || _currentProduct.Cost > 999999)
                errors.AppendLine("Неправильная цена от 1 до 999999");
            //if (_currentProduct.Manufacturer == null)
                //errors.AppendLine("Выбери производителя");



            if (errors.Length > 0)
            {
                MessageBox.Show(errors.ToString());
                return;
            }

            if (_currentProduct.ID == 0)
                SaparovEntities2.GetContext().Products.Add(_currentProduct);

            try {
                SaparovEntities2.GetContext().SaveChanges();
                MessageBox.Show("Информация сохранена");
                Manager.MainFrame.GoBack();
                }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString());
            }
        }

        
    }

    





}
